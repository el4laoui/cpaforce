<?php
$oc_config = array (
    
    //================================================================================================
   

    "favicon"         => "favicon.png" ,

    //================================================================================================

    "sitelogo"        => "MOVIES STREAMING",
    
    "sitename"        => "MOVIES STREAMING",

    "sitedescription" => "Watch Full Movies Streaming HD Quality and Full Episode TV Shows for FREE",

    "sitekeywords"    => "",

    "sitethemes"      => "custom_v1",

    "offer_link1"     => "//hlok.qertewrt.com/offer?prod=21&ref=5103012",


    // "sport_offer"     => "",        // Jika Belum Di Include Plugin Sport nya gak bisa di gunakan

    "histatsID"       => "3426671",

    //================================================================================================

    "tvdb_search"     => "true",

    "cache"           => "true",

    "_seo"            => "false",

    "_stt"            => "true",

    "protect_content" => "false",       // disable klik kanan, block text, copy paste pada halaman LP

    "search_url"      => "search",

    "url_end"         => ".html",
    
    "category_url"    => "genre",
    
    "timezone"        => "Asia/Jakarta",

    "debug"           => "true",

);