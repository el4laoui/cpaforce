<?php

require_once __DIR__.'/config.php';
require_once __DIR__.'/options.php';
require_once __DIR__.'/../core/functions.php';
require_once __DIR__.'/../core/php-hooks.php';
require_once __DIR__.'/../core/general-templates.php';
require_once __DIR__.'/../core/data.php';
require_once __DIR__.'/../core/term.php';
require_once __DIR__.'/../../vendor/autoload.php';
require_once __DIR__.'/../class/class.tvdb.php';