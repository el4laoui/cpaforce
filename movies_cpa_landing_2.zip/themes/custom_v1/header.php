<?php 
/*
| -------------------------------------------------------------------------------
| Author            : Mathin Mochammad
| Template Name     : Custom LP V1 (Movie Only)
| -------------------------------------------------------------------------------
*/
$sub = '';
if (isset($_GET['sub'])) {
	$sub = $_GET['sub'];
	session_start();
	$_SESSION['sub'] = $_GET['sub'];
}
 ?>

<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title itemprop="name"><?php oc_title();?></title>
	<meta name="description" content="<?php oc_description();?>">
	<meta name="keywords" content="<?php echo config('sitekeywords');?>" />
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="author" content="admin">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<meta property="og:locale" content="en_US">
	<meta property="og:title" content="<?php oc_title() ?>" />
	<meta property="og:description" content="<?php oc_description();?>">
	<meta property="og:type" content="website" />
	<meta property="og:author" content="Admin">
	<meta property="og:site_name" content="<?php echo config('sitename') ?>">
	<meta property="og:url" content="<?php echo site_uri() ?>" />
	<link rel="shortcut icon" href="<?php style_theme() ?>/img/favicon.png">
	
	<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" media='all'>
	<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" media='all'>
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Roboto%3A400%2C300%2C700" media='all'>
	<link rel="stylesheet" type="text/css" href="<?php style_theme() ?>/css/default.min.css">
	<link rel="stylesheet" type="text/css" href="<?php style_theme() ?>/css/style.min.css">
	<?php oc_head(); ?>
</head>
<?php if (isset($kondisi)): ?>
	<?php if ($kondisi == 'tmdb_movie'): ?>
		<body class="single single-movie postid-3078 desktop subdo single-movie-offer">
			<div id="video-player">
				<div class="container">
					<div id="magelo-player">
						<div class="embed-responsive embed-responsive-16by9">

							<iframe id="intro" class="embed-responsive-item" src="https://www.youtube.com/embed/bkifvuuIrXs?hd=1&amp;autoplay=0&amp;rel=0&amp;controls=0&amp;showinfo=0&amp;modestbranding=1" data-duration="27000" frameborder="0">
							</iframe>

							<div id="cover-top">
							</div>
							<div id="cover-bottom">
							</div>
							<video id="videoPlayer" class="embed-responsive-item" preload="none" poster="<?php echo $images;?>">
								<p>Your browser doesn't support HTML5 video.</p>
							</video>

							<span class="play-wrapper ease">
								<span id="play" class="fa fa-youtube-play ease">
								</span>
							</span>
							<div class="media-controls">
								<div id="leftControls">
									<button type="button" name="Play" class="btn glyphicon glyphicon-play" id="play_btn">
									</button>
									<button id="volumeInc_btn" name="Volume" class="btn glyphicon glyphicon-volume-up">
									</button>
									<button id="timeContainer" class="btn"><?php echo format_time($runtime) ?><span class="timer"></span>
									</button>
								</div>

								<div id="progressContainer">
									<span id="progress-bar" class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" data-count="0.387931034483%">
									</span>
								</div>
								<div id="rightControls">
									<div id="sliderContainer">
										<div id="slider" class="ui-slider ui-slider-vertical ui-widget ui-widget-content ui-corner-all">
											<div class="ui-slider-range ui-widget-header ui-corner-all ui-slider-range-min" style="height: 50%;">
											</div>
											<span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0" style="bottom: 50%;">
											</span>
										</div>
									</div>
									<div id="setting_btn" class="btn-group dropup">
										<button name="Setting" class="btn glyphicon glyphicon-cog dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											<span class="glyphicon glyphicon-hd-video">
											</span>
										</button>
										<ul class="dropdown-menu dropdown-menu-right">
											<li class="hq active">HD 1080p</li>
											<li class="hq">HD 720p</li>
										</ul>
									</div>
									<button id="fullscreen_btn" name="Fullscreen" class="btn glyphicon glyphicon-resize-full">
									</button>
								</div>


							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="modal-offer" data-domain="#" data-campaign="" data-movie="<?php echo $row['imdb_id'] ?>" data-title="<?php echo $title ?>" class="modal fade pointer" onclick="go_ads()">
				<div class="modal-dialog">
					<div id="login" class="modal-content">
						<div class="top-content" style="background-image:url(<?php echo $w780 ?>)">
							<p class="text-center top"><?php echo $title;?></p>
							<p class="text-center bottom">Released Date: <?php echo date('M d, Y', strtotime($release_date));?></p>
						</div>
						<div class="bottom-content">
							<img class="img-responsive" src="<?php echo style_theme() ?>/img/offer.png" width="614" height="275">
							<p class="text-center">
								<a class="btn btn-primary btn-lg" href="<?php echo config('offer_link1') . '&sub_id=' . $sub ?>">Register Free Account</a>
							</p>
						</div>
					</div>
				</div>
			</div>	
		<?php endif ?>
	<?php else: ?>
		<body class="postid-3078 desktop subdo single-movie-offer">
		<div id="cover-top">
							</div>
							<div id="cover-bottom">
							</div>
<?php endif ?>
	
	<div id="page">
		<header id="masthead" class="site-header" role="banner">
			<nav id="site-navigation" class="navbar navbar-fixed-top navbar-default main-navigation" role="navigation">
				<div class="container">
					<div class="row">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#primary-menu" aria-expanded="false">
								<span class="sr-only">Primary Menu</span>
								<span class="icon-bar">
								</span>
								<span class="icon-bar">
								</span>
								<span class="icon-bar">
								</span>
							</button>
							<div class="site-branding">
								<h1 class="site-title">
									<a href="<?php echo site_url() ?>" rel="home">
										<span class="text-color glyphicon glyphicon-facetime-video">
										</span> <?php echo config('sitelogo'); ?></a>
									</h1>
								</div>
							</div>
							<div id="primary-menu" class="collapse navbar-collapse">
								<ul id="menu-pages" class="nav navbar-nav nav-menu" aria-expanded="false">
									<li id="menu-item-1033" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1033">
										<a title="Toprated Movies" href="javascript:;" onclick="go_ads()" >Toprated Movies</a>
									</li>
									<li id="menu-item-1034" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1034">
										<a title="Popular Movies" href="javascript:;" onclick="go_ads()" >Popular Movies</a>
									</li>
									<li id="menu-item-1035" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1035">
										<a title="New Realese Movies" href="javascript:;" onclick="go_ads()" >New Realese Movies</a>
									</li>
								</ul>
								<form method="get" class="navbar-form navbar-right" role="search" action="/" onsubmit="go_ads()">
									<div class="input-group">
										<input type="text" name="s" class="form-control" placeholder="Search">
										<span class="input-group-btn">
											<button type="submit" class="btn btn-primary">
												<span class="glyphicon glyphicon-search">
												</span>
											</button>
										</span>
									</div>
								</form>
							</div>
						</div>
					</div>
				</nav>
			</header>

			<div id="content" class="site-content clearfix bgrn">
				<div class="container" itemscope itemtype="http://schema.org/Movie">
					<div class="row">

