<?php
/*
| -------------------------------------------------------------------------------
| Author            : Mathin Mochammad
| Template Name     : Muvimag V2
| -------------------------------------------------------------------------------
*/

$kondisi = 'tmdb_movie';
include('functions.php');
include('header.php');
?>

<div class="content-area col-md-8" id="primary">
<main class="site-main" id="main" role="main">
<div class="row">
<div class="col-md-12">

<center><a href="javascript:;" onclick="go_ads()"><img src="<?php echo style_theme() ?>/img/download.png"></a></center>



<ul class="breadcrumb" id="crumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
<span itemprop="name">
<a href="<?php echo site_url() ?>" itemprop="item">
<i class="glyphicon glyphicon-home">
</i>
</a>
</span>
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
<span itemprop="name">
<a href="" itemprop="item">Movie</a>
</span>
</li>
<li class="active"><?php echo $title ?></li>
</ul>
</div>
</div>
<article class="landing_page post-3078 movie type-movie status-publish hentry collection-world-war-z-collection company-2dux company-apparatus-productions company-gk-films company-hemisphere-media-capital company-latina-pictures company-paramount-pictures company-skydance-productions country-malta country-united-states-of-america genre-action genre-drama genre-horror genre-science-fiction genre-thriller keyword-apocalypse keyword-dystopia keyword-flesh-eating-zombies keyword-multiple-perspectives keyword-nuclear-weapons keyword-zombie-apocalypse keyword-zombies language-english people-abigail-hargrove people-brad-pitt people-damon-lindelof people-daniella-kertesz people-david-andrews people-david-ellison people-david-morse people-drew-goddard people-elyes-gabel people-fabrizio-zacharee-guido people-fana-mokoena people-j-michael-straczynski people-james-badge-dale people-julia-levy-boeken people-konstantin-khabenskiy people-ludi-boeken people-marc-forster people-marco-beltrami people-matthew-fox people-max-brooks people-mireille-enos people-moritz-bleibtreu people-nick-bartlett people-peter-capaldi people-pierfrancesco-favino people-ruth-negga people-sterling-jerins people-troy-glasgow " id="post-3078">
<header class="entry-header">
<h1 class="entry-title text-ellipsis">
<span itemprop="name"><?php echo $title ?></span>
</h1>
<div class="tagline">
<i>
<strong><?php echo $tagline ?></strong>
</i>
</div>
<meta content="2016-06-30">
<div itemprop="aggregateRating" itemscope itemtype= "http://schema.org/AggregateRating">
<meta content="1">
<meta content="10">
<meta content="4.03">
<meta content="10">
</div>
</header>
<!-- .entry-header -->
<div class="entry-content">
<div class="row">
<div class="col-md-3 text-center poster-container">
<a href=" ">
<img itemprop="image" alt="<?php echo $title ?>" class="img-responsive main-poster" src="<?php echo $images_small ?>" height="278" width="185"/>
</a>
</div>
<div class="col-md-9 lead" itemprop="description"><?php echo $row['overview'] ?></div>
</div>
<div class="row">
<div class="col-md-12">
<ul class="nav nav-tabs">
<li class="active">
<a href="#details">Details</a>
</li>

</ul>
<div class="tab-content">
<div class="tab-panein active" id="details" role="tabpanel">
<div class="table-responsive">
<table class="table table-condensed table-bordered table-hover">
<tbody>
<tr>
<th>Title</th>
<td>
<strong><?php echo $title ?></strong>
</td>
</tr>
<tr>
<th>Release Date</th>


<td><?php echo date('M d, Y', strtotime($release_date));?></td>
</tr>
<tr>
<th>Genres</th>
<td>
<a href="" rel="tag">
<?php echo $genre;?>
</a>
</td>
</tr>
<tr>
<th>Runtime</th>
<td>
<time itemprop="duration" content="PT116M"><?php echo waktu($runtime) ?></time>
</td>
</tr>
<tr>

<th>Production Companies</th>
<td>
<?php echo $companies ?>
</td>
</tr>
<tr>
<th>Production Countries</th>
<td>
<?php echo $country ?>
</td>
</tr>
<tr>

<th>Cast</th>
<td>
<?php echo $cast ?>
</td>
</tr>

</tbody>
</table>
</div>
</div>

<!-- .entry-content -->
<footer class="entry-footer">
</footer>
<!-- .entry-footer -->
</article>
<!-- #post-## -->
<div class="row">
<div class="col-md-12">
<h3 class="sub-section">
<span>Popular Movies</span>
</h3>
<div class="clearfix">
</div>
<ul id="movie-related" class="cycle-slideshow cycle-list" data-cycle-slides="> li" data-cycle-fx=carousel data-cycle-timeout=0 data-cycle-next="#next" data-cycle-prev="#prev">
<?php  
$Movies = unserialize( ocim_data_movie('home_movie_popular_',1, 'getPopularMovies') );
?>
<?php if (is_array($Movies['result'])): ?>
	<?php foreach ( (array) array_slice($Movies['result'], 0, 18) as $rowz ): ?>
		<li>
		<a href="<?php echo seo_movie($rowz['id'],$rowz['title']) ?>" data-toggle="tooltip" data-placement="top" title="<?php echo $rowz['title'] ?>">
		<img src="<?php echo $rowz['poster_path'];?>" width="130" height="195" alt="<?php echo $rowz['title'] ?>" />
		<div class="list-title"><?php echo $rowz['title'] ?></div>
		<div class="rating" data-toggle="tooltip" data-placement="right" title="7.7 of 10 stars">

		</div>
		</a>
		</li>
	<?php endforeach ?>	
<?php endif ?>
		
</ul>
<div class="lrnav">
<a href="#" id="prev">
<span class="glyphicon glyphicon-chevron-left">
</span>
</a>
<a href="#" id="next">
<span class="glyphicon glyphicon-chevron-right">
</span>
</a>
</div>
</div>
</div>
</main>
<!-- #main -->
<!-- #post-## -->
<div class="row">
<div class="col-md-12">

<div class="lrnav">
<a href="#" id="prev">
<span class="glyphicon glyphicon-chevron-left">
</span>
</a>
<a href="#" id="next">
<span class="glyphicon glyphicon-chevron-right">
</span>
</a>
</div>
</div>
</div>
</main>
<!-- #main -->
</div>
<!-- #primary -->
<aside class="widget-area col-md-4" id="secondary" role="complementary">
<section class="widget" id="widget-comments">
<h3 class="sub-section">
<span>Review</span>
<a href="javascript:;" onclick="go_ads()" class="pull-right more">See All</a>
</h3>
<div class="clearfix">
</div>
<?php if (!empty($row['reviews']['results'])): ?>
	<?php foreach ($row['reviews']['results'] as $rev => $revi): ?>
		<div class="list-group-item review clearfix" itemprop="review" itemscope itemtype="http://schema.org/Review">
		<meta itemprop="itemReviewed" content="<?php echo $title ?>">
			<meta itemprop="author" content="<?php echo $rev['author'] ?>">
			<meta itemprop="datePublished" content="">
			<div class="comment-author vcard">
				<div class="gravatar">
				</div>
				<cite class="fn"><?php echo $revi['author'] ?></cite>

			</div>
			<div class="title-wrapper">

				<div class="rating" itemprop="reviewRating" itemscope itemtype="http://schema.org/Rating">
					<meta itemprop="worstRating" content="1">
					<meta itemprop="ratingValue" content="8">
					<meta itemprop="bestRating" content="10">
					<span title="8 Stars" data-toggle="tooltip" data-placement="right">
						<span class="rating-symbol glyphicon glyphicon-star on">
						</span>
						<span class="rating-symbol glyphicon glyphicon-star on">
						</span>
						<span class="rating-symbol glyphicon glyphicon-star on">
						</span>
						<span class="rating-symbol glyphicon glyphicon-star on">
						</span>
						<span class="rating-symbol glyphicon glyphicon-star on">
						</span>
						<span class="rating-symbol glyphicon glyphicon-star on">
						</span>
						<span class="rating-symbol glyphicon glyphicon-star on">
						</span>
						<span class="rating-symbol glyphicon glyphicon-star on">
						</span>
						<span class="rating-symbol glyphicon glyphicon-star off">
						</span>
						<span class="rating-symbol glyphicon glyphicon-star off">
						</span>
					</span>
				</div>
			</div>
			<div class="review-content" itemprop="reviewBody"><?php echo limit_review($revi['content']) ?>
			</div>
		</div>
	<?php endforeach ?>
<?php endif ?>
</section>

</aside>

<!-- #secondary -->
</div>
</div>
</div>


<footer id="colophon" class="site-footer" role="contentinfo">
<div id="movie-genre-list">
<div class="container">
<div class="row">
<ul class="clearfix">
<?php foreach ($_cate as $cateid => $catename): ?>
<li class="col-md-3 col-sm-4 col-xs-6"><a href="javascript:;" onclick="go_ads()"><span class="fa fa-circle-o">
 <?php echo ucwords($catename) ?></a></li>
<?php endforeach ?>
</ul>
</div>
</div>
</div>
<?php include('footer.php');?>


