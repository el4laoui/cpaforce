<?php 
/**
 * The template for displaying page dmca
 *
 * @package www.ocimscripts.com
 * @subpackage tmdbtwo
 * @since TMDB Two 1.0
 */
$hack_title = 'DMCA Notice';
$hack_description = "If you believe that your copyrighted work has been copied in a way that constitutes copyright infringement and is accessible on this site.";
get_header(); ?>
<div id="primary" class="content-area col-md-8 sidebar-">
<main id="main" class="site-main" role="main">
<article id="post-1020" class="post-1020 page type-page status-publish hentry ">
<header class="page-header">
<h1 class="page-title">DMCA</h1>
</header>
<!-- .page-header -->
<div class="page-content">
<p>BIG MOVIE respects the intellectual property of others. BIG MOVIE takes matters of Intellectual Property very seriously and is committed to meeting the needs of content owners while helping them manage publication of their content online. It should be noted that BIG MOVIE is a simple search engine of TV series available at a wide variety of third party websites.</p>
<p>If you believe that your copyrighted work has been copied in a way that constitutes copyright infringement and is accessible on this site, you may notify our copyright agent, as set forth in the <strong>Digital Millennium Copyright Act</strong> of 1998 (DMCA). For your complaint to be valid under the DMCA, you must provide the following information when providing notice of the claimed copyright infringement:</p>
<ul>
<li>A physical or electronic signature of a person authorized to act on behalf of the copyright owner Identification of the copyrighted work claimed to have been infringed</li>
<li>Identification of the material that is claimed to be infringing or to be the subject of the infringing activity and that is to be removed</li>
<li>Information reasonably sufficient to permit the service provider to contact the complaining party, such as an address, telephone number, and, if available, an electronic mail address</li>
<li>A statement that the complaining party "in good faith believes that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or law"</li>
<li>A statement that the "information in the notification is accurate", and "under penalty of perjury, the complaining party is authorized to act on behalf of the owner of an exclusive right that is allegedly infringed"</li>
</ul>
<p>The above information must be submitted as a written, faxed or emailed notification using <span class="pointer" data-toggle="modal" data-target="#modal-dmca">
<strong>this form</strong>
</span>
</p>
<div id="modal-dmca" class="modal fade">
<div class="modal-dialog">
<div class="modal-content" style="margin-top: 175px;">
<form id="dmca-form" method="POST" action="">
<input type="hidden" name="dmca-post" value="1">
<div class="modal-header bg-primary">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h3 class="text-shadow text-center">
<strong>DMCA Notice</strong>
</h3>
</div>
<div class="modal-body">
<div class="input-group">
<span class="input-group-addon" id="sizing-addon1">
<span class="glyphicon glyphicon-user">
</span> Name</span>
<input type="text" class="form-control" name="dmca-name" placeholder="Real Name" aria-describedby="sizing-addon1">
</div>
<div class="input-group">
<span class="input-group-addon" id="sizing-addon2">
<span class="glyphicon glyphicon-envelope">
</span> Email</span>
<input type="text" class="form-control" name="dmca-email" placeholder="Valid Email Address" aria-describedby="sizing-addon2">
</div>
<div class="input-group">
<span class="input-group-addon" id="sizing-addon3">
<span class="glyphicon glyphicon-copyright-mark">
</span> IMDB ID</span>
<input type="text" class="form-control" name="dmca-imdb" placeholder="ex. tt1234567" aria-describedby="sizing-addon3">
</div>
<div class="input-group">
<textarea class="form-control" name="dmca-reason" rows="5" placeholder="State your claims here...">
</textarea>
</div>
<div class="input-group">
<div class="checkbox">
<label>
<input type="checkbox" name="dmca-agree"> I have read and agree with <strong>Privacy</strong> and <strong>DMCA Policy</strong>
</label>
</div>
</div>
</div>
<div class="modal-footer">
<div class="pull-right">
<button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Cancel</button>
<button class="btn btn-primary" type="submit">Submit</button>
</div>
</div>
</form>
</div>
</div>
</div>
<p class="alert alert-warning">WE CAUTION YOU THAT UNDER FEDERAL LAW, IF YOU KNOWINGLY MISREPRESENT THAT ONLINE MATERIAL IS INFRINGING, YOU MAY BE SUBJECT TO HEAVY CIVIL PENALTIES. THESE INCLUDE MONETARY DAMAGES, COURT COSTS, AND ATTORNEYS' FEES INCURRED BY US, BY ANY COPYRIGHT OWNER, OR BY ANY COPYRIGHT OWNER'S LICENSEE THAT IS INJURED AS A RESULT OF OUR RELYING UPON YOUR MISREPRESENTATION. YOU MAY ALSO BE SUBJECT TO CRIMINAL PROSECUTION FOR PERJURY.</p>
<p>This information should not be construed as legal advice, for further details on the information required for valid DMCA notifications, see 17 U.S.C. 512(c)(3).</p>
</div>

<?php get_footer(); ?>