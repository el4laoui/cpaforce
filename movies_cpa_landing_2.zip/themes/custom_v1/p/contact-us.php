<?php 
$hack_title = 'Contact Us';
$hack_description = "Please feel free to contact us using the form below.";
get_header(); ?>
<div id="primary" class="content-area col-md-8 sidebar-">
<main id="main" class="site-main" role="main">
<article id="post-1017" class="post-1017 page type-page status-publish hentry ">
<header class="page-header">
<h1 class="page-title">Contact</h1>
</header>
<!-- .page-header -->
<div class="page-content"> <br>
<form id="contact-form" method="POST" class="clearfix">
<div class="input-group">
<span class="input-group-addon" id="sizing-addon1">
<span class="glyphicon glyphicon-user">
</span> Name</span>
<input type="text" class="form-control" name="contact-name" placeholder="Your Real Name" aria-describedby="sizing-addon1">
</div>
<div class="input-group">
<span class="input-group-addon" id="sizing-addon2">
<span class="glyphicon glyphicon-envelope">
</span> Email</span>
<input type="text" class="form-control" name="contact-email" placeholder="Your Valid Email Address" aria-describedby="sizing-addon2">
</div>
<div class="input-group">
<span class="input-group-addon" id="sizing-addon3">
<span class="glyphicon glyphicon-asterisk">
</span> Messsage Title</span>
<input type="text" class="form-control" name="contact-title" placeholder="Give your message a title" aria-describedby="sizing-addon3">
</div>
<div class="input-group">
<textarea class="form-control" name="contact-message" rows="5" placeholder="Your Message...">
</textarea>
</div>
<div class="pull-right">
<button class="btn btn-primary" type="submit">Send Messsage</button>
</div>
</form>
</div>
<!-- .page-content -->
<footer class="page-footer">
</footer>
<!-- .page-footer -->
</article>
<!-- #post-## -->
</main>
<!-- #main -->
</div>
<?php get_sidebar(); ?>

<?php get_footer(); ?>