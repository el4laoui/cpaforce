<?php  
$home 		= true;
$id_movie 	= 'tt5052448';

include('functions.php');

if ($home == false) {
	$TMDBID = $id_movie;
	$kondisi = 'tmdb_movie';
	$path	  = $_SERVER['DOCUMENT_ROOT'] . '/cache/movie/';
	$basename = $TMDBID.'.json';
	if ( file_exists( $path . $basename ) && ! ocim_expire( $path . $basename , 86400 ) ) {
		$data = @file_get_contents( $path . $basename );
		$row = unserialize( $data );
	} else {
		$apikey = tmdb_api();
		$tmdb = new TMDB($apikey, en, true);
		$row = $tmdb->getMovie($TMDBID);
	}
	if ( !$row[status_code] == 34 ) {
		$title          = $row['title'];
		$tagline        = $row['tagline'];

		$cm['id']       = $TMDBID;
		$cm['title']    = $row['title'];
		$cm['slug']     = seo_movie( $TMDBID, $row['title'] );
		$cm['pubdate']  = $row['release_date'];

		$randone        = $movie_title_awal[mt_rand(0, count($movie_title_awal) - 1)];
		$randtwo        = $movie_title_akhir[mt_rand(0, count($movie_title_akhir) - 1)];
		$release_date   = $row['release_date'];
		$year           = date('Y', strtotime( $release_date ) );
		$hack_title     = $randone . $row['title'] .' ('.$year.') '. $randtwo;
		$title_after    = ' | '.config('sitename');
		$description    = $randone . $row['title'] .' ('.$year.') : '.$randtwo.' '.$row['overview'];
		$runtime        = $row['runtime'];
		$vote_count     = $row['vote_count'];

		if ($row[images]['backdrops']!=null) {
			shuffle($row[images]['backdrops']);
			foreach($row[images]['backdrops'] as $result) {
				$images = 'http://image.tmdb.org/t/p/w1920' . $result['file_path'];
				$w780 = 'http://image.tmdb.org/t/p/w780' . $result['file_path'];
			}
		} elseif ($row[images]['posters']!=null){
			shuffle($row[images]['posters']);
			foreach($row[images]['posters'] as $result) {
				$images = 'http://image.tmdb.org/t/p/w1920' . $result['file_path'];
				$w780 = 'http://image.tmdb.org/t/p/w780' . $result['file_path'];
			}
		} else {
			$images = site_theme().'/images/no-backdrop.png';
			$w780 = site_theme().'/images/no-backdrop.png';
		}
		if ($row['poster_path']!=null) {
			$images_small = 'http://image.tmdb.org/t/p/w185' . $row['poster_path'];
		} elseif ($row['backdrop_path']!=null){
			$images_small = 'http://image.tmdb.org/t/p/w185' . $row['backdrop_path'];
		} else {
			$images_small = site_theme().'/images/no-cover.png';
		}
		if (is_array($row['genres'])){
			$genres  = array();foreach($row['genres'] as $result) : $genres[] = '<span itemprop="genre"><a itemprop="url" href="'.seocat(permalink($result['name']),$result['id']).'">'.$result['name'].'</a></span>';endforeach;
			$genre = implode(", ",$genres);
		}
		if (is_array($row['genres'])){
			foreach($row['genres'] as $result) : $category = $result['name'];$categoryid = $result['id'];endforeach;
		}
		if (is_array($row['credits'][cast]))
		{       
			$ic = 0;$casts = array();foreach($row['credits'][cast] as $result) :$casts[] = '<span itemprop="actor" itemscope itemtype="http://schema.org/Person"><span itemprop="name">'.$result['name'].'</span></span>';if ($ic++ == 10) break;endforeach;
			$cast = implode(", ",$casts);
		}
		if($row['vote_average'] > 0) {
			$get_rating =  $row['vote_average'];
			$emp_rating =  11 - $get_rating;
		} else {
			$emp_rating = 10;
		}
		if (is_array($row['keywords']['keywords']))
		{
			$keyword = array();foreach($row['keywords']['keywords'] as $result) : $keyword[] = '<span class="itemprop" itemprop="keywords">'.$result['name'].'</span>';endforeach;
			$keywords = implode(", ",$keyword);
		}
		if (is_array($row['production_countries']))
		{
			$countrys = array();foreach($row['production_countries'] as $result) : $countrys[] = $result['name'];endforeach;
			$country = implode( ", ",$countrys );
		}
		if (is_array($row['production_companies']))
		{
			$production = array();foreach($row['production_companies'] as $result) : $production[] = '<span itemprop="creator" itemscope itemtype="http://schema.org/Organization"><span itemprop="name">'.$result['name'].'</span></span>';endforeach;
			$companies = implode(", ",$production);
		}
		if ( $row['title'] != '' ) {
			if ( !file_exists( $path ) ) {
				mkdir( $path, 0755, true );
				file_put_contents( $path . $basename, serialize( $row ) );
				file_put_contents( $_SERVER['DOCUMENT_ROOT'] . '/cache/single/' . $basename, serialize( $cm ) );
			}else {
				file_put_contents( $path . $basename, serialize( $row ) );
				file_put_contents( $_SERVER['DOCUMENT_ROOT'] . '/cache/single/' . $basename, serialize( $cm ) );
			}
		} else{
			ocim_throw();
		}
	} else {
		ocim_throw();
	}
	$aksi = 'home_2.php';
}
else {
	$aksi = 'home_1.php';
}
include($aksi);
?>