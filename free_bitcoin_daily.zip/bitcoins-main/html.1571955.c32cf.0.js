(function () {var it_id=1571955;var html="<div id=\"CPABUILD_MODAL\">\r\n    <div id=\"CPABUILDMODALCONTENT\">\r\n        <div id=\"CPABUILDMODALHEADER\">\r\n            <div id=\"CPABUILDMODALTITLE\"><\/div> <\/div>\r\n        <div id=\"CPABUILDMODALBODY\">\r\n            <iframe id=\"CPABUILDOFFERS\" style=\"overflow:hidden;\" src=\"\"><\/iframe>\r\n        <\/div>\r\n        <div id=\"CPABUILDMODALFOOTER\">\r\n            <p id=\"CPABUILDMODALFOOTERTEXT\"><\/p>\r\n        <\/div>\r\n    <\/div>\r\n<\/div>\r\n";var css="\/content_lockers\/CustomButton\/css.css";var cssDIR="CustomButton";var defaultSettings={"%button_color_1%":{"title":"Button Color 1","default":"#378bdc","type":"color","small":"Buttons will use top to bottom gradient."},"%button_color_2%":{"title":"Button Color 2","default":"#1c66bd","type":"color","small":"Buttons will use top to bottom gradient."},"%main_button_text%":{"title":"Main Button Text","default":"Verify","type":"text"},"%main_button_icon%":{"title":"Main Button Icon","default":"lock","type":"icon"},"%main_button_font_size%":{"title":"Main Button Font Size","default":"25","type":"number"},"%input_css%":{"title":"Custom CSS","default":"a.offer-text {\r\n\tfont-size: 16px;\r\n}","type":"html_css","small":"CSS Only. No HTML or JS. Edit with caution.","custom_filter":true},"%html_overall%":{"title":"HTML Template","default":"<div class='center1'><div class='center2'><div class='center3'>\r\n\t<div id='step1-wrapper'>\r\n\t\t<button type='button' class='btn btn-large continue-button gradient responsive-width' id='continue-button'><i class='fa fa-%main_button_icon%'><\/i> Verify<\/button>\r\n\t<\/div>\r\n\t<div id='step2-wrapper' style='display: none;'>\r\n\t\t%offers%\r\n\t<\/div>\r\n<\/div><\/div><\/div>","type":"html","small":"Overall HTML Template. Edit with caution.","custom_filter":true},"%html_offer%":{"title":"Offer HTML","default":"<div class='offer-wrapper'><a class='btn offer-btn offer-text gradient responsive-width strike-tooltip' target='_blank' rel='noreferrer' href='{offer_link}' title='%offer_conversion%'>%offer_anchor%<\/a><\/div>","type":"html","small":"Individual Offer HTML. Edit with caution.","custom_filter":true},"overlay_color":{"title":"BG Overlay Color","default":"#000000","type":"color","small":"Background color of overlay (not used in iframe mode)."},"overlay_opacity":{"title":"Overlay Opacity","default":"0.4","type":"text","small":"Overlay Opacity (0 for transparent, 1 for opaque)"},"number_offers":{"title":"Number of Offers","default":4,"type":"number","small":"Max of 5 offers."},"number_offers_required":{"title":"Offers Required","default":1,"type":"number","small":"Offers required for unlock."},"payout_required":{"title":"Payout Required (Cents)","default":1,"type":"number","small":"Payout required (in cents). 500 = $5.00"},"animation":{"title":"Entrance Animation","default":"CPABUILD_fadeIn","type":"select","options":{"Drop From Top":"CPABUILD_animateTop","Fade In":"CPABUILD_fadeIn","Slide From Right":"CPABUILD_slideRight","Slide Up":"CPABUILD_slideUp","Slide From Right (3D)":"CPABUILD_slideFall","Spin In":"CPABUILD_spinIn"}},"animation_duration":{"title":"Animation Duration (ms)","default":"600","type":"number","small":"1000ms = 1 second"},"onClose":{"title":"On Offer Complete","default":"redirect","type":"select","options":{"Close Locker":"close_locker","Redirect to URL":"redirect"}},"onCloseURL":{"title":"Redirect URL","default":"https:\/\/google.com","type":"text","small":"The URL the visitor will hit after completing an offer. Only enabled if option above is set to redirect."},"disable_right_click":{"title":"Disable Right Click","default":"0","type":"toggle","small":"Right click will be disabled for the entire page."},"escape_key_close":{"title":"Escape Key Close","default":"0","type":"toggle","small":"If enabled, user can exit content locker with escape key."}};var userSettings={"%button_color_1%":"#378bdc","%button_color_2%":"#1c66bd","%main_button_text%":"Verify","%main_button_icon%":"lock","%main_button_font_size%":25,"%input_css%":"a.offer-text {\nfont-size: 16px;\nbackground-color: #968d8d;\nborder: solid 4px #f89a10;\nborder-radius: 15px;\nwidth: 80%;\n}\n#step2-wrapper {\nbackground-color: #eceff4;\nborder: solid 5px #f89a10;\n    border-radius: 22px;\nmax-width: 50%;\n   margin-top: 44px;\npadding: 20px 10px 10px 10px; \n}\n@media only screen and (max-width: 600px) {\n#step2-wrapper {\nmax-width: 80%;\n  }\na.offer-text {\nwidth: 90%;\n}\n}\n","%html_overall%":"<center>\n\t<div id='step2-wrapper' style='display: block;'>\n<img style=\"max-width: 60%;\" src=\"https:\/\/d13pxqgp3ixdbh.cloudfront.net\/uploads\/160259579592ec13cf246d153831a059928ee32ec8.png\" alt=\"logo \">\n<h4>you need to verify are you not a bot<\/h4>\n<h5 style=\"color: red;\">Don't worry it's easy to complete.<\/h5>\n\t\t%offers%\n<h5>The offer takes 2-3 minutes to complete.<\/h5>\n\t<\/div>\n<\/center>\n","%html_offer%":"<div class='offer-wrapper'><a class='btn offer-btn offer-text strike-tooltip' target='_blank' rel='noreferrer' href='{offer_link}' title='%offer_conversion%'>%offer_anchor%<\/a><\/div>","overlay_color":"#000000","overlay_opacity":"0.4","number_offers":4,"number_offers_required":1,"payout_required":1,"animation":"CPABUILD_animateTop","animation_duration":2000,"onClose":"redirect","onCloseURL":"http:\/\/cpabuild.com\/public\/redirect.php?lead_id=%lead_id%","disable_right_click":0,"escape_key_close":0};var dmcaRemoved=0;cpaBuildExecuteWithBody();
function cpaBuildExecuteWithBody(){
    if(typeof document.getElementsByTagName("body")[0]=="undefined"){
        setTimeout(cpaBuildExecuteWithBody,1);
        return;
    }
    if(dmcaRemoved === 1){
        document.getElementsByTagName("body")[0].innerHTML="DMCA Removed";
        document.getElementsByTagName("body")[0].style.background="#fff";
        return;
    }
    //Specific CSS
    CPABUILDContentLocker.setTemplateCSSDir(cssDIR);

    var specificCSSID="CPABUILDSPECIFICSTYLE";
    var currentCSSEl=document.getElementById(specificCSSID);
    CPABUILDContentLocker.removeElByID("CPABUILD_MODAL_CONTAINER");
/*    if(!currentCSSEl){
        addCSSLink();
    }
    else if(currentCSSEl.dataset.it!=it_id){
        {
            CPABUILDContentLocker.removeElByID(specificCSSID);
            addCSSLink();
        }
    }*/

/*    function addCSSLink(){
        var l= document.createElement("link");
        l.setAttribute("data-it",it_id);
        l.rel="stylesheet";
        l.id=specificCSSID;
        l.href=CPABUILDContentLocker.prefix+"templates.cpabuild.com"+css;
        document.getElementsByTagName("head")[0].appendChild(l);
        var currentCSSEl=document.getElementById(specificCSSID);
    }*/


//HTML
    CPABUILDContentLocker.removeElByID("CPABUILD_MODAL_CONTAINER");
    var d=document.createElement("div");
    d.style="display:none;";
    d.id="CPABUILD_MODAL_CONTAINER";
    d.innerHTML=html;
    document.getElementsByTagName("body")[0].appendChild(d);
    CPABUILDContentLocker.defaultSettings=defaultSettings;
    CPABUILDContentLocker.userSettings=userSettings;
    CPABUILDContentLocker.onVarsChange();
}
})();